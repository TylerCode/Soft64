﻿using System;
using System.Windows;
using Soft64.Engines;

namespace Soft64WPF.ViewModels
{
    public class EmulatorEngineViewModel : QuickDependencyObject
    {
        //internal EmulatorEngineViewModel()
        //{
        //}

        //private void EngineStatusChangedHandler(Object sender, EngineStatusChangedArgs e)
        //{
        //    Dispatcher.Invoke(() =>
        //    {
        //        Status = e.NewStatus;
        //    });
        //}

        //private static readonly DependencyPropertyKey StatusPropertyKey =
        //    DependencyProperty.RegisterReadOnly("Status", typeof(EngineStatus), typeof(EmulatorEngineViewModel),
        //    new PropertyMetadata());

        //public static readonly DependencyProperty StatusProperty =
        //    StatusPropertyKey.DependencyProperty;

        //public EngineStatus Status
        //{
        //    get { return (EngineStatus)GetValue(StatusProperty); }
        //    private set { SetValue(StatusPropertyKey, value); }
        //}


        //public EmulatorEngine CurrentEngine = MachineViewModel.CurrentModel.CurrentMachine.
    }
}