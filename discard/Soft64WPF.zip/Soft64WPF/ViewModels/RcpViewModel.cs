﻿using System.Windows;
using Soft64;

namespace Soft64WPF.ViewModels
{
    public sealed class RcpViewModel : DependencyObject
    {
        internal RcpViewModel()
        {
        }
    }
}