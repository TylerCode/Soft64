﻿namespace Soft64WPF
{
    public enum BlockType
    {
        Hex,
        Ascii
    }
}